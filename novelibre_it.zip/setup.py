#!/usr/bin/python3
"""Installation script."""
import setuplib

setuplib.main(False)
